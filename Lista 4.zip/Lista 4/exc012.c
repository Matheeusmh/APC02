/*-------------------------------------------------------------------------
Aluno: Matheus Henrique de Andrade Pires
Matrícula: 202301138
Turma:  IBT0007 - ALGORITMOS E PROGRAMAÇÃO DE COMPUTADORES 2 (2023 .2 - TA)
        IBT0209 - LABORATÓRIO DE PROGRAMAÇÃO 2 (2023 .2 - TA)
Curso: Ciência da Computação
UFCAT - Universidade Federal de Catalão
Data de criação: 10/12/2023
---------------------------------------------------------------------------
12) Critique a função recursiva que pretende encontrar o valor de um
elemento máximo de v[0..n-1]. */
int MaximoR2(int v[], int n)
{
    if (n == 1) // Condição de parada e retorno do primeiro elemento para comparação;
        return v[0]; // Retorno do valor do primeiro elemento;
    if (MaximoR2(v, n - 1) < v[n - 1]) // Chamada da função MaximoR2() e comparação na recursão;
        return v[n - 1]; // Retornando o maior valor;
    else
        return MaximoR2(v, n - 1); // Chamada da função MaximoR2() novamente e retorno pós recursão.
}
/* A função dada tende a achar o elemento de maior valor, assim, retornando o mesmo.
Ela é uma versão simplificada da função anterior, mas apresenta um comportamento inesperado mediante diferentes entradas.*/