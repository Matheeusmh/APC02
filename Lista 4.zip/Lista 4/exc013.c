/*-------------------------------------------------------------------------
Aluno: Matheus Henrique de Andrade Pires
Matrícula: 202301138
Turma:  IBT0007 - ALGORITMOS E PROGRAMAÇÃO DE COMPUTADORES 2 (2023 .2 - TA)
        IBT0209 - LABORATÓRIO DE PROGRAMAÇÃO 2 (2023 .2 - TA)
Curso: Ciência da Computação
UFCAT - Universidade Federal de Catalão
Data de criação: 10/12/2023
---------------------------------------------------------------------------
• 13) Implemente o exemplo visto.
– Se X é a função recursiva abaixo, qual o valor de X(7)?
int X(int n){
if(n==1 || n==2) return n;
else return X (n-1) + n * X(n-2);
} */
#include <stdio.h>

int X(int n);

int main(void)
{
    printf("Resultado: %d", X(7));

    return (0);
}
int X(int n)
{
    if (n == 1 || n == 2)
        return n;
    else
        return X(n - 1) + n * X(n - 2);
}

// Resposta X(7): 382