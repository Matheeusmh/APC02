/*-------------------------------------------------------------------------
Aluno: Matheus Henrique de Andrade Pires
Matrícula: 202301138
Turma:  IBT0007 - ALGORITMOS E PROGRAMAÇÃO DE COMPUTADORES 2 (2023 .2 - TA)
        IBT0209 - LABORATÓRIO DE PROGRAMAÇÃO 2 (2023 .2 - TA)
Curso: Ciência da Computação
UFCAT - Universidade Federal de Catalão
Data de criação: 10/12/2023
---------------------------------------------------------------------------
14) O que há de errado com a função recursiva?
*/
int XX(int n)
{
    if (n == 0)
        return 0;
    else
        return XX(n / 3 + 1) + n;
}

/* O erro na função recursiva está na condição de parada, isto é, a condição não está bem definida
,o que pode levar a um loop infinito de chamadas. */