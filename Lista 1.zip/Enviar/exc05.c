/*-------------------------------------------------------------------------
Aluno: Matheus Henrique de Andrade Pires
Matrícula: 202301138
Turma:  IBT0007 - ALGORITMOS E PROGRAMAÇÃO DE COMPUTADORES 2 (2023 .2 - TA)
        IBT0209 - LABORATÓRIO DE PROGRAMAÇÃO 2 (2023 .2 - TA)
Curso: Ciência da Computação
UFCAT - Universidade Federal de Catalão
Data de criação: 30/10/2023
---------------------------------------------------------------------------
5. Leia um vetor com 20 números inteiros. Crie a função repetidos() para acessar os
elementos do vetor e imprimir eliminando os números repetidos. */
#include <stdio.h>

void repetidos(int vet[]);

int main(void)
{
    // Declaração de variável:
    int vet[20], i;

    // Solicitação e entrada dos 20 valores do vetor:
    printf("___ELIMINANDO REPETIDOS___\n");
    printf("Digite 20 valores numericos: ");
    for (i = 0; i < 20; i++)
    {
        scanf("%d", &vet[i]); // Armazenar.
    }

    repetidos(vet); // Chamando a função repetidos().

    return (0);
}

// Função para imprimir os valores do vetor eliminando os repetidos:
void repetidos(int vet[])
{
    // Declaração de variáveis:
    int count = 0, j, i;

    // Imprimir os valores eliminando os repetidos:
    printf("\n __SEM REPETIDOS__\n ");
    for (i = 0; i < 20; i++)
    {
        count = 0;
        for (j = i - 1; j >= 0; j--)
        {
            if (vet[i] == vet[j]) // Verificar se o valor é repetido;
            {
                count++;
                break;
            }
        }
        if (count == 0) // Verificando se o valor já foi impresso.
        {
            printf("%d ", vet[i]);
        }
    }
    printf("\n");
}
