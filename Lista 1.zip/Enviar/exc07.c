/*-------------------------------------------------------------------------
Aluno: Matheus Henrique de Andrade Pires
Matrícula: 202301138
Turma:  IBT0007 - ALGORITMOS E PROGRAMAÇÃO DE COMPUTADORES 2 (2023 .2 - TA)
        IBT0209 - LABORATÓRIO DE PROGRAMAÇÃO 2 (2023 .2 - TA)
Curso: Ciência da Computação
UFCAT - Universidade Federal de Catalão
Data de criação: 30/10/2023
---------------------------------------------------------------------------
7. Faça um vetor de tamanho 50 preenchido com o seguinte valor: (i+ 5 ∗
i)%(i+ 1), sendo i a posição do elemento no vetor. Em seguida, usando a
função imprima() mostre os valores do vetor. */
#include <stdio.h>

void imprima(int vet[]);

int main(void)
{
    // Declaração de variável:
    int vet[50], i;

    // Realizar o cálculo:
    for (i = 0; i < 50; i++)
    {
        vet[i] = (i + 5 * i) % (i + 1);
    }

    imprima(vet); // Chamando a função imprimir.

    return (0);
}

// Função para imprimir o vetor:
void imprima(int vet[])
{
    // Declaração de variável:
    int i;

    for (i = 0; i < 50; i++)
    {
        printf("%d ", vet[i]);
    }
    printf("\n");
}
